/**
 * Members view model
 */

var app = app || {};

app.on2tClients = (function () {
    'use strict'
    var locals;
    var clientViewModel = (function () {
        var properties
        var clientClassModel = {
            fields: {
                place: {
                    field: 'Place',
                    defaultValue: ''
                },
                url: {
                    field: 'Website',
                    defaultValue: 'www.on2t.com'
                },
                marker: {
                    field: 'Location',
                    defaultValue: []
                },
                text: {
                    field: 'Description',
                    defaultValue: 'Empty'
                }
            }
        };
        var clientDataSource = new kendo.data.DataSource({
            type: 'everlive',
            schema: {
                model: clientModel
            },
            transport: {
                typeName: 'Places'
            }
        });
        var itemViewModel = kendo.data.ObservableObject.extend({
            attribute: null,
            isViewInitialized: false,
            markers: [],
            details: [],
            hideView: false,
            itemMarker: function (marker, text) {
                var itemPosition = new google.maps.LatLng(marker.latitude, marker.longitude);
                marker.Mark = new google.maps.Marker({
                    map: map,
                    position: position,
                    icon: {
                        url: 'styles/images/icon.png',
                        anchor: new google.maps.Point(20, 38),
                        scaledSize: new google.maps.Size(40, 40)
                    }
                });
                google.maps.event.addListener(marker.Mark, 'click', function () {
                    infoWindow.setContent(text);
                    infoWindow.open(map, marker.Mark);
                });
            },
        });
        return {
            init: function () {
                //common variables 
                if (typeof google === "undefined") {
                    return;
                }

                infoWindow = new google.maps.InfoWindow();
                //create empty LatLngBounds object
                allBounds = new google.maps.LatLngBounds();

                var pos, userCords, streetView, tempPlaceHolder = [];

                var mapOptions = {

                }

                map = new google.maps.Map(document.getElementById("map-canvas"), mapOptions);

            },
            show: function () {
                //resize the map in case the orientation has been changed 
                google.maps.event.trigger(map, "resize");
            },
            hide: function () {
                //hide loading mask if user changed the tab as it is only relevant to location tab
                kendo.mobile.application.hideLoading();
            },
            viewModel: new clientViewModel(),
            onSelected: function (e) {
            }
        };
    });
    return {
        clientViewModel: clientViewModel,
        initClients: function () {

        },
        showClients: function () {

        }
    }

}());
